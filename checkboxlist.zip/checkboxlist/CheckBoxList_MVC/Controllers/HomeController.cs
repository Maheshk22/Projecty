﻿using System;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.Configuration;
using System.Data.SqlClient;
using System.Collections.Generic;
using CheckBoxList_MVC.Models;

namespace CheckBoxList_MVC.Controllers
{
    public class HomeController : Controller
    {
        List<SelectListItem> checkBoxList = new List<SelectListItem>();
        public HomeController()
        {
            List<SelectListItem> items = new List<SelectListItem>();
            items.Add(new SelectListItem { Text = "B.Tech", Value = "1" });
            items.Add(new SelectListItem { Text = "M.Tech", Value = "2" });
            items.Add(new SelectListItem { Text = "MCA", Value = "3" });
            checkBoxList = items;
        }
        // GET: Home
        public ActionResult Index()
        {
            //ViewBag.CheckBoxList = checkBoxList;
            return View(checkBoxList);
        }

        [HttpPost]
        public ActionResult Index(List<SelectListItem> items)
        {            
            string selectedValues = string.Join(",", items.Where(x => x.Selected).Select(x => x.Value));
            string selectedTexts = string.Join(",", items.Where(x => x.Selected).Select(x => x.Text));

            return View(items);
        }
    }
}