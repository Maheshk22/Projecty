using CheckBoxList_MVC.Models;
using System;
using System.Data.Entity;
using System.Linq;

namespace CheckBoxList_MVC
{
    public class DataModel : DbContext
    {
        public DataModel()
            : base("name=DBContext")
        {
        }


         public virtual DbSet<Student> Students { get; set; }
    }

    //public class MyEntity
    //{
    //    public int Id { get; set; }
    //    public string Name { get; set; }
    //}
}